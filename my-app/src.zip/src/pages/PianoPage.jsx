import InstrumentPage from "./InstrumentPage";

export default function PianoPage() {
  return <InstrumentPage instrument="piano" />;
}
