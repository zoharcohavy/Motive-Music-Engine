// src/pages/PianoPage.jsx
import React from "react";
import InstrumentPage from "./InstrumentPage";

export default function PianoPage() {
  return <InstrumentPage instrument="piano" />;
}
