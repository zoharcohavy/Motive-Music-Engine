import InstrumentPage from "./InstrumentPage";

export default function DrumPage() {
  return <InstrumentPage instrument="drums" />;
}
