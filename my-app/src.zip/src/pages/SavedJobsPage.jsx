export default function SavedJobsPage(){
    return (
    <div className="page-container">
    <h2>Saved jobs</h2>
    <p>List saved jobs for the current user here.</p>
    </div>
    )
    }