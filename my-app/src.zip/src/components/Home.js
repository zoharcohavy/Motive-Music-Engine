

const Home = () => {

  return (
    <div>
        First addition.
    </div>
  );
};

export default Home;